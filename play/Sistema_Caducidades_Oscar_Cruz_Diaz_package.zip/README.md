# Sistema de Caducidades — Proyecto Original

Desarrollado por **Óscar Cruz Díaz (RFC: CUDO000714Q61)**  
© 2025 Todos los derechos reservados.

---

## ⚙️ Descripción
Sistema de control de caducidades y gestión de inventarios diseñado y
programado íntegramente por el autor. Este proyecto representa el resultado
de investigación, desarrollo, y trabajo técnico individual.

---

## 🛡️ Licencia
**Licencia propietaria — Todos los derechos reservados.**

No se permite el uso, copia, modificación, ni distribución del contenido
de este repositorio sin autorización escrita y firmada del autor.

El uso o implementación de este software por parte de la **Universidad
Politécnica de Tlaxcala**, **Tiendas 3B** o cualquier institución pública
o privada **está prohibido sin contrato y pago de derechos**.

Cualquier violación será motivo de acciones legales conforme a la Ley
Federal del Derecho de Autor (México).

---

## 💬 Agradecimientos
Este proyecto fue creado con apoyo conceptual de herramientas de
inteligencia artificial (OpenAI ChatGPT), las cuales sirvieron de soporte
educativo.  
Todas las ideas, estructura, lógica y dirección técnica son
propiedad exclusiva de **Óscar Cruz Díaz**.

---

## 📩 Contacto
Para licencias comerciales, soporte o acuerdos de uso:
**tu_correo@example.com**
