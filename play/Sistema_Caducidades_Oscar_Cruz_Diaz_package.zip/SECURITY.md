# Política de Seguridad

© 2025 Óscar Cruz Díaz (RFC: CUDO000714Q61)

Este repositorio y su contenido son propiedad exclusiva del autor.  
Cualquier intento de uso, copia o explotación no autorizada será tratado
como una vulneración a los derechos de propiedad intelectual.

## Reporte de vulnerabilidades o uso indebido
Si detectas uso no autorizado o vulneración de derechos, comunícalo a:
📧 tu_correo@example.com

El autor se reserva el derecho de emprender acciones legales en caso de
violación a esta política.

## Responsabilidad
El código no se distribuye con garantía alguna y **no puede ser utilizado**
fuera de las condiciones de licencia firmadas por el autor.
