# Instrucciones básicas para Registro en INDAUTOR (México)

1. Reúne la evidencia:
   - README.md, LICENSE, SECURITY.md (con tu nombre y RFC).
   - Archivo ZIP del proyecto (incluye código y documentación).
   - Historial de commits y tags firmados (si los tienes).
   - Copias de correos o pruebas de autoría.

2. Prepara el ejemplar de obra:
   - Empaqueta un ZIP con el código y documentación (mantén una copia offline).

3. Completa el formulario de INDAUTOR:
   - En la web de INDAUTOR busca el trámite de registro de obras de software.

4. Paga las tasas correspondientes:
   - Consulta el monto y plazos actualizados en la web oficial o con un abogado.

5. Presenta la documentación y espera resolución:
   - Conserva comprobantes de pago y la constancia de registro.

6. Si necesitas ayuda:
   - Considera asesoría legal especializada en propiedad intelectual.

Nota: los procedimientos y costos pueden variar; estas son pautas generales.
