# Contrato de Licencia Comercial (Plantilla)

**Partes:**
- Licenciante: Óscar Cruz Díaz (RFC: CUDO000714Q61) — "El Autor"
- Licenciatario: [NOMBRE DE LA EMPRESA / INSTITUCIÓN] — "El Licenciatario"

**Objeto:**
El Autor concede al Licenciatario una licencia limitada, no exclusiva y
temporal para usar el "Sistema de Caducidades" únicamente en los términos
y condiciones establecidos en este contrato, y únicamente tras el pago
y firma del presente acuerdo.

**Alcance de la licencia:**
- Uso: [Describir el uso permitido: p.ej., un sólo establecimiento, no sublicenciable]
- Prohibiciones: queda expresamente prohibido sublicenciar, distribuir,
  publicar o adaptar el software sin autorización escrita del Autor.

**Compensación y pago:**
- Precio: [Monto en MXN o la moneda acordada]
- Forma de pago: [Transferencia bancaria / PayPal / otro]
- Plazo de pago: [p.ej., 30 días naturales desde la firma]

**Entrega y soporte:**
- Entrega: El Autor entregará el código fuente y documentación al Licenciatario
  tras confirmación de pago y firma del contrato.
- Soporte: [Opcional — horas de soporte incluidas, tarifas adicionales]

**Duración y terminación:**
- Vigencia: [p.ej., 1 año, renovable]
- Incumplimiento: El incumplimiento de las obligaciones de pago o uso
  permitirá la terminación inmediata y reclamación de daños.

**Confidencialidad:**
- El Licenciatario se compromete a no divulgar información sensible
  técnica ni comercial relacionada con el sistema sin autorización.

**Jurisdicción:**
- Este contrato se regirá por las leyes de los Estados Unidos Mexicanos.
  Cualquier disputa será sometida a los tribunales competentes.

**Firmas:**

_________________________________  
Óscar Cruz Díaz (Licenciante)

_________________________________  
[Nombre y cargo del representante del Licenciatario] (Licenciatario)

Fecha: ____ / ____ / 20__
